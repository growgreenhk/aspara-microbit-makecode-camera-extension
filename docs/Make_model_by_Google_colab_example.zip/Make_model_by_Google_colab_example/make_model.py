%cd /content
from google.colab import files
uploaded = files.upload()  # ← upload the .zip you just created
!unzip My_Project.zip
%cd /content/My_Project
!pip install tf-keras
!pip install pillow
!pip install scipy
!python train_tflite.py