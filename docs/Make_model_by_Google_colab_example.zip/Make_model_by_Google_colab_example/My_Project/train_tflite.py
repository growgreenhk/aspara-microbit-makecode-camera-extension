import tensorflow as tf
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.applications import MobileNetV2
from tensorflow.keras.layers import Dense, GlobalAveragePooling2D, Dropout
from tensorflow.keras.models import Model
import os
import numpy as np
import shutil
from pathlib import Path

# ============== CONFIGURATION ==============
DATASET_DIR = "dataset"
IMG_SIZE = 224
BATCH_SIZE = 8
EPOCHS_HEAD = 30
EPOCHS_HEAD = 30
EPOCHS_FINE = 20
TFLITE_INT8_MODEL_PATH = "model.tflite"   # Your final tiny model
LABELS_PATH = "labels.txt"
SAVED_MODEL_DIR = "temp_saved_model"           # temporary, will be deleted

# ============== Data Augmentation & Loading ==============
datagen = ImageDataGenerator(
    rescale=1./255,
    validation_split=0.2,
    rotation_range=40,
    width_shift_range=0.3,
    height_shift_range=0.3,
    shear_range=0.3,
    zoom_range=0.4,
    horizontal_flip=True,
    brightness_range=[0.6, 1.4],
    fill_mode='nearest'
)

train_generator = datagen.flow_from_directory(
    DATASET_DIR,
    target_size=(IMG_SIZE, IMG_SIZE),
    batch_size=BATCH_SIZE,
    class_mode='categorical',
    subset='training',
    shuffle=True
)

val_generator = datagen.flow_from_directory(
    DATASET_DIR,
    target_size=(IMG_SIZE, IMG_SIZE),
    batch_size=BATCH_SIZE,
    class_mode='categorical',
    subset='validation'
)

# Save labels.txt
class_names = sorted(train_generator.class_indices.keys())
print("Classes:", class_names)
with open(LABELS_PATH, 'w') as f:
    for idx, name in enumerate(class_names):
        f.write(f"{idx} {name}\n")
print(f"Labels saved → {LABELS_PATH}")

# ============== Build Model ==============
base_model = MobileNetV2(weights='imagenet', include_top=False, input_shape=(IMG_SIZE, IMG_SIZE, 3))
base_model.trainable = False

x = base_model.output
x = GlobalAveragePooling2D()(x)
x = Dropout(0.5)(x)
predictions = Dense(len(class_names), activation='softmax')(x)

model = Model(inputs=base_model.input, outputs=predictions)

# ============== Phase 1: Train only the head ==============
model.compile(optimizer=tf.keras.optimizers.Adam(0.001),
              loss='categorical_crossentropy',
              metrics=['accuracy'])

print("Phase 1: Training classification head...")
model.fit(train_generator, epochs=EPOCHS_HEAD, validation_data=val_generator)

# ============== Phase 2: Fine-tuning (unfreeze base) ==============
base_model.trainable = True
model.compile(optimizer=tf.keras.optimizers.Adam(1e-5),  # very low LR
              loss='categorical_crossentropy',
              metrics=['accuracy'])

print("Phase 2: Fine-tuning entire model...")
model.fit(train_generator, epochs=EPOCHS_FINE, validation_data=val_generator)

# ============== Export with correct preprocessing (critical for TFLite int8) ==============
@tf.function(input_signature=[tf.TensorSpec([None, 224, 224, 3], tf.float32)])
def serve(images):
    # MobileNetV2 expects inputs in [-1, 1]
    processed = (images * 2.0) - 1.0
    return {"predictions": model(processed, training=False)}

print("Exporting model for TFLite conversion...")
model.export(SAVED_MODEL_DIR, serving=serve)

# ============== Representative dataset for FULL INT8 quantization ==============
def representative_data_gen():
    for batch in train_generator:
        images, _ = batch
        for i in range(images.shape[0]):
            img = (images[i:i+1] * 2.0) - 1.0  # [0,1] → [-1,1]
            yield [img.astype(np.float32)]
        if len(list(train_generator)) * BATCH_SIZE >= 200:
            break

# ============== Convert to FULL INT8 TFLite (input/output = uint8) ==============
# Fast representative dataset using numpy directly (no ImageDataGenerator = no hanging)
def representative_dataset():
    folder = Path("dataset")
    i = 0
    for img_path in folder.rglob("*.jpg"):
        if i >= 200:
            break
        img = tf.io.read_file(str(img_path))
        img = tf.image.decode_jpeg(img, channels=3)
        img = tf.image.resize(img, [224, 224])
        img = img / 255.0                     # → [0,1]
        img = img * 2.0 - 1.0                  # → [-1,1] like MobileNetV2
        img = tf.expand_dims(img, 0)           # → (1,224,224,3)
        yield [img.numpy().astype(np.float32)]
        i += 1

print("Starting FULL INT8 quantization (fast version)...")
converter = tf.lite.TFLiteConverter.from_saved_model("temp_saved_model")

converter.optimizations = [tf.lite.Optimize.DEFAULT]
converter.representative_dataset = representative_dataset
converter.target_spec.supported_ops = [tf.lite.OpsSet.TFLITE_BUILTINS_INT8]
converter.inference_input_type = tf.uint8      # camera/apps give uint8
converter.inference_output_type = tf.uint8     # tiny & fast

# This line is the key — forces full integer quantization without fallback
converter._experimental_lower_to_full_integer_quantization = True

tflite_model = converter.convert()

# Save
with open("model.tflite", "wb") as f:
    f.write(tflite_model)

size = os.path.getsize("model.tflite") / (1024*1024)
print(f"\nSUCCESS — model.tflite created → {size:.2f} MB")

# Clean up temp folder
shutil.rmtree("temp_saved_model", ignore_errors=True)